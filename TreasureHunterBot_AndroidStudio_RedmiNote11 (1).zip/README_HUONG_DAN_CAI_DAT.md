# HƯỚNG DẪN CÀI ĐẶT TOOL LÊN ĐIỆN THOẠI REDMI NOTE 11

Dự án này chứa đầy đủ mã nguồn Android Studio (Kotlin) để tạo ra ứng dụng Auto-Bot dạng Nút Nổi cho game Treasure Hunter MMORPG.

## CÁC BƯỚC CÀI ĐẶT LÊN ĐIỆN THOẠI:

### Bước 1: Mở dự án trong Android Studio
1. Tải và cài đặt Android Studio (nếu chưa có) từ: https://developer.android.com/studio
2. Giải nén thư mục này. Trong Android Studio, chọn "Open" và trỏ vào thư mục giải nén.
3. Chờ Gradle đồng bộ (Sync) hoàn tất trong 1-2 phút.

### Bước 2: Cài đặt trực tiếp lên Redmi Note 11 qua cáp USB
1. Trên điện thoại Redmi Note 11:
   - Vào Cài đặt -> Giới thiệu điện thoại -> Nhấn liên tục 7 lần vào "Phiên bản MIUI" (hoặc HyperOS) để bật Chế độ nhà phát triển.
   - Quay lại Cài đặt bổ sung -> Tùy chọn nhà phát triển -> Bật "Gỡ lỗi USB" (USB Debugging) và "Cài đặt qua USB" (Install via USB).
2. Cắm cáp USB nối điện thoại với máy tính.
3. Trong Android Studio, chọn thiết bị là "Xiaomi Redmi Note 11" ở thanh trên cùng và ấn nút **Run ▶** (màu xanh lá).
4. Ứng dụng sẽ tự động được cài đặt và mở lên trên điện thoại.

### Hoặc Bước 2b: Xuất file APK để copy vào điện thoại
1. Trong Android Studio, vào thanh menu: **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
2. Khi build xong, ấn vào nút **"locate"** để lấy file `app-debug.apk`.
3. Gửi file `app-debug.apk` sang điện thoại Redmi Note 11 (qua Zalo, Telegram hoặc cáp) và bấm Cài đặt.

### Bước 3: Cấp 3 quyền trên điện thoại Redmi Note 11
Khi mở app Treasure Hunter Bot lần đầu:
1. Nhấn nút 1: Cấp quyền "Hiển thị trên ứng dụng khác" -> Bật cho phép.
2. Nhấn nút 2: Cấp quyền "Trợ năng" (Accessibility) -> Chọn "Ứng dụng đã tải xuống" -> Chọn "Treasure Hunter Bot" -> Bật Cho phép.
3. Nhấn nút 3: "BẬT NÚT TRÒN NỔI & MỞ GAME" -> Chọn "Bắt đầu ngay" khi hệ thống hỏi quyền chụp màn hình.

### Bước 4: Chơi game
- Nút tròn ảo hình ⛏️ sẽ xuất hiện nổi trên màn hình.
- Mở game Treasure Hunter lên.
- Bạn có thể kéo nút tròn đến vị trí thuận tay.
- Nhấp vào nút tròn -> Ấn **"BẮT ĐẦU AUTO-DRAG"** -> Bot sẽ tự động quét các khối đá trắng, đất nâu, xanh rêu và tự kéo cần gạt ảo để di chuyển!
